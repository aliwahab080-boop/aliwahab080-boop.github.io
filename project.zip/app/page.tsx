import { SalimaApp } from '@/components/salima/salima-app'

export default function Page() {
  return <SalimaApp />
}
