export const AGENCY = {
  name: 'Salima Transfert',
  city: 'Niamey',
  phoneDisplay: '99 96 37 77',
  phoneIntl: '+22799963777',
  whatsapp: '22799963777',
}

export const PI_RATE_FCFA = 1200
export const USDT_RATE_FCFA = 600
export const PIN_CODE = '1234'

export type Currency = 'FCFA' | 'Pi' | 'USDT'
export type TxStatus = 'success' | 'cancelled'
export type TransferService = 'NITA' | 'AMANA'

export type Transaction = {
  id: string
  code: string
  type: 'envoi' | 'reception' | 'service'
  service: string
  label: string
  counterpart: string
  phone?: string
  country: string
  city?: string
  amountFcfa: number
  feesFcfa: number
  totalFcfa: number
  currency: Currency
  amountOriginal: number
  status: TxStatus
  date: string
  sender: string
}

export const SENDER_NAME = 'Salima Transfert'

const fcfaFormatter = new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 })
const piFormatter = new Intl.NumberFormat('fr-FR', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})

export function formatFcfa(value: number) {
  return `${fcfaFormatter.format(Math.round(value)).replace(/\u202f|\u00a0/g, ' ')} FCFA`
}

export function formatPi(value: number) {
  return `${piFormatter.format(value).replace(/\u202f|\u00a0/g, ' ')} Pi`
}

export function formatUsdt(value: number) {
  return `${piFormatter.format(value).replace(/\u202f|\u00a0/g, ' ')} USDT`
}

export function formatOriginal(tx: Pick<Transaction, 'currency' | 'amountOriginal'>) {
  if (tx.currency === 'Pi') return formatPi(tx.amountOriginal)
  if (tx.currency === 'USDT') return formatUsdt(tx.amountOriginal)
  return formatFcfa(tx.amountOriginal)
}

// Niamey is UTC+1 year-round; manual formatting keeps server and browser output identical.
export function formatDate(iso: string) {
  const d = new Date(new Date(iso).getTime() + 60 * 60 * 1000)
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${pad(d.getUTCDate())}/${pad(d.getUTCMonth() + 1)}/${d.getUTCFullYear()} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`
}

export function computeFees(amountFcfa: number, service: TransferService, international: boolean) {
  if (amountFcfa <= 0) return 0
  const rate = international ? 0.03 : service === 'NITA' ? 0.015 : 0.01
  const minimum = international ? 1000 : 200
  return Math.max(minimum, Math.round(amountFcfa * rate))
}

export function generateCode() {
  return `SAL${Math.floor(1000 + Math.random() * 9000)}`
}

export const NIGER_CITIES = [
  'Niamey',
  'Dosso',
  'Maradi',
  'Zinder',
  'Tahoua',
  'Agadez',
  'Tillabéri',
  'Diffa',
  'Gaya',
  "Birni N'Konni",
  'Tessaoua',
  'Dogondoutchi',
  'Filingué',
  'Say',
  'Kollo',
  'Madarounfa',
  'Magaria',
  'Mirriah',
  'Tanout',
  'Arlit',
  'Madaoua',
  'Illéla',
  'Bouza',
  'Keita',
  'Abalak',
  'Tchintabaraden',
  'Dakoro',
  'Mayahi',
  'Guidan Roumdji',
  'Aguié',
  'Gouré',
  'Matamèye',
  'Mainé-Soroa',
  "N'Guigmi",
  'Bilma',
  'Ingall',
  'Iférouane',
  'Téra',
  'Ouallam',
  'Ayorou',
  'Torodi',
  'Balleyara',
  'Loga',
  'Boboye',
  'Birni Gaouré',
  'Falmey',
  'Tibiri',
  'Dioundiou',
  'Hamdallaye',
  'Karma',
  'Liboré',
  'Torodi',
  'Makalondi',
  'Kantché',
  'Takieta',
  'Damagaram Takaya',
  'Belbédji',
  'Gazaoua',
  'Malbaza',
  'Galmi',
  'Tsernaoua',
  'Bagaroua',
  'Tassara',
  'Banibangou',
  'Abala',
  'Sanam',
  'Tondikiwindi',
  'Gotheye',
  'Dargol',
  'Kourteye',
  'Bankilaré',
  'Goudel',
  'Saga',
  'Bangoula',
  'Koygolo',
  'Harikanassou',
  'Kiota',
  'Matankari',
  'Soucoucoutane',
  'Doutchi Tounga',
  'Chadakori',
  'Tibiri Maradi',
  'Sabon Machi',
  'Dan Issa',
  'Djirataoua',
  'Gangara',
  'Droum',
  'Bandé',
  'Dungass',
  'Wacha',
  'Bosso',
  'Chétimari',
  'Kablewa',
  'Toumour',
].filter((city, index, list) => list.indexOf(city) === index)

const PRIORITY_COUNTRIES = [
  'NE',
  'FR',
  'NG',
  'GH',
  'BJ',
  'TG',
  'BF',
  'ML',
  'SN',
  'CI',
  'CM',
  'US',
  'TD',
  'DZ',
  'LY',
  'MA',
  'BE',
  'IT',
  'ES',
  'DE',
  'GB',
  'CA',
  'SA',
  'AE',
  'CN',
  'TR',
]

const ALL_COUNTRY_CODES = [
  'AF','AL','DZ','AD','AO','AG','AR','AM','AU','AT','AZ','BS','BH','BD','BB','BY','BE','BZ','BJ','BT',
  'BO','BA','BW','BR','BN','BG','BF','BI','CV','KH','CM','CA','CF','TD','CL','CN','CO','KM','CG','CD',
  'CR','CI','HR','CU','CY','CZ','DK','DJ','DM','DO','EC','EG','SV','GQ','ER','EE','SZ','ET','FJ','FI',
  'FR','GA','GM','GE','DE','GH','GR','GD','GT','GN','GW','GY','HT','HN','HU','IS','IN','ID','IR','IQ',
  'IE','IL','IT','JM','JP','JO','KZ','KE','KI','KW','KG','LA','LV','LB','LS','LR','LY','LI','LT','LU',
  'MG','MW','MY','MV','ML','MT','MH','MR','MU','MX','FM','MD','MC','MN','ME','MA','MZ','MM','NA','NR',
  'NP','NL','NZ','NI','NE','NG','KP','MK','NO','OM','PK','PW','PS','PA','PG','PY','PE','PH','PL','PT',
  'QA','RO','RU','RW','KN','LC','VC','WS','SM','ST','SA','SN','RS','SC','SL','SG','SK','SI','SB','SO',
  'ZA','KR','SS','ES','LK','SD','SR','SE','CH','SY','TW','TJ','TZ','TH','TL','TG','TO','TT','TN','TR',
  'TM','TV','UG','UA','AE','GB','US','UY','UZ','VU','VA','VE','VN','YE','ZM','ZW',
]

export type Country = { code: string; name: string; priority: boolean }

const regionNames = new Intl.DisplayNames(['fr'], { type: 'region' })

export const COUNTRIES: Country[] = (() => {
  const priority = PRIORITY_COUNTRIES.map((code) => ({
    code,
    name: regionNames.of(code) ?? code,
    priority: true,
  }))
  const others = ALL_COUNTRY_CODES.filter((code) => !PRIORITY_COUNTRIES.includes(code))
    .map((code) => ({ code, name: regionNames.of(code) ?? code, priority: false }))
    .sort((a, b) => a.name.localeCompare(b.name, 'fr'))
  return [...priority, ...others]
})()

export function countryName(code: string) {
  return COUNTRIES.find((c) => c.code === code)?.name ?? code
}

export function normalize(text: string) {
  return text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
}

export function buildBeneficiaryMessage(tx: Transaction) {
  const location = tx.city ? `${tx.city}, ${countryName(tx.country)}` : countryName(tx.country)
  return [
    `SALIMA TRANSFERT`,
    `Bonjour ${tx.counterpart},`,
    `Vous avez reçu ${formatFcfa(tx.amountFcfa)} via ${tx.service}.`,
    `Expéditeur : ${tx.sender}`,
    `Ville de retrait : ${location}`,
    `Code de retrait : ${tx.code}`,
    `Date : ${formatDate(tx.date)}`,
    `Présentez ce code et une pièce d'identité à l'agence.`,
    `Info : ${AGENCY.phoneDisplay}`,
  ].join('\n')
}

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 't1',
    code: 'SAL4821',
    type: 'envoi',
    service: 'NITA',
    label: 'Envoi NITA',
    counterpart: 'Moussa Issoufou',
    phone: '96 12 45 78',
    country: 'NE',
    city: 'Maradi',
    amountFcfa: 50000,
    feesFcfa: 750,
    totalFcfa: 50750,
    currency: 'FCFA',
    amountOriginal: 50000,
    status: 'success',
    date: '2026-11-25T08:42:00Z',
    sender: 'Salima Transfert',
  },
  {
    id: 't2',
    code: 'SAL7310',
    type: 'envoi',
    service: 'AMANA',
    label: 'Envoi AMANA',
    counterpart: 'Aïchatou Hamani',
    phone: '90 33 21 10',
    country: 'NE',
    city: 'Zinder',
    amountFcfa: 24000,
    feesFcfa: 240,
    totalFcfa: 24240,
    currency: 'Pi',
    amountOriginal: 20,
    status: 'success',
    date: '2026-11-24T15:10:00Z',
    sender: 'Salima Transfert',
  },
  {
    id: 't3',
    code: 'SAL1957',
    type: 'service',
    service: 'Pi → USDT',
    label: 'Conversion Pi → USDT',
    counterpart: 'Portefeuille USDT',
    country: 'NE',
    amountFcfa: 12000,
    feesFcfa: 120,
    totalFcfa: 12120,
    currency: 'USDT',
    amountOriginal: 20,
    status: 'success',
    date: '2026-11-23T11:25:00Z',
    sender: 'Salima Transfert',
  },
  {
    id: 't4',
    code: 'SAL6604',
    type: 'envoi',
    service: 'NITA',
    label: 'Envoi international',
    counterpart: 'Ibrahim Diallo',
    phone: '+33 6 12 34 56 78',
    country: 'FR',
    amountFcfa: 100000,
    feesFcfa: 3000,
    totalFcfa: 103000,
    currency: 'FCFA',
    amountOriginal: 100000,
    status: 'cancelled',
    date: '2026-11-21T09:05:00Z',
    sender: 'Salima Transfert',
  },
  {
    id: 't5',
    code: 'SAL2288',
    type: 'reception',
    service: 'AMANA',
    label: 'Réception AMANA',
    counterpart: 'Halima Souley',
    phone: '93 77 88 12',
    country: 'NE',
    city: 'Niamey',
    amountFcfa: 30000,
    feesFcfa: 0,
    totalFcfa: 30000,
    currency: 'FCFA',
    amountOriginal: 30000,
    status: 'success',
    date: '2026-11-20T17:48:00Z',
    sender: 'Halima Souley',
  },
  {
    id: 't6',
    code: 'SAL9043',
    type: 'service',
    service: 'NIGELEC',
    label: 'Facture NIGELEC',
    counterpart: 'Compteur 0412 5587',
    country: 'NE',
    amountFcfa: 15500,
    feesFcfa: 155,
    totalFcfa: 15655,
    currency: 'FCFA',
    amountOriginal: 15500,
    status: 'success',
    date: '2026-11-18T10:12:00Z',
    sender: 'Salima Transfert',
  },
]
