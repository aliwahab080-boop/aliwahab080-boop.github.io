'use client'

import { useEffect } from 'react'
import { ArrowLeft, X } from 'lucide-react'
import { cn } from '@/lib/utils'

export function Logo({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const box = size === 'lg' ? 'size-14 text-2xl' : size === 'sm' ? 'size-8 text-sm' : 'size-10 text-lg'
  return (
    <div className="flex items-center gap-2.5">
      <div
        className={cn(
          'flex items-center justify-center rounded-2xl bg-primary font-black text-primary-foreground',
          box,
        )}
        aria-hidden="true"
      >
        S
      </div>
      <div className="leading-none">
        <p className={cn('font-black tracking-tight text-foreground', size === 'lg' ? 'text-2xl' : 'text-base')}>
          SALIMA
        </p>
        <p className="mt-0.5 text-[10px] font-semibold uppercase tracking-[0.25em] text-primary">Transfert</p>
      </div>
    </div>
  )
}

export function PrimaryButton({
  className,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      {...props}
      className={cn(
        'flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-primary px-5 text-base font-bold text-primary-foreground transition-all active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary',
        className,
      )}
    />
  )
}

export function SecondaryButton({
  className,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      {...props}
      className={cn(
        'flex h-14 w-full items-center justify-center gap-2 rounded-2xl border border-border bg-secondary px-5 text-base font-semibold text-foreground transition-all active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary',
        className,
      )}
    />
  )
}

export function ScreenHeader({ title, onBack, subtitle }: { title: string; onBack?: () => void; subtitle?: string }) {
  return (
    <div className="flex items-center gap-3 pb-4">
      {onBack && (
        <button
          type="button"
          onClick={onBack}
          aria-label="Retour"
          className="flex size-11 shrink-0 items-center justify-center rounded-full border border-border bg-secondary text-foreground active:scale-95"
        >
          <ArrowLeft className="size-5" />
        </button>
      )}
      <div className="min-w-0">
        <h1 className="text-balance text-2xl font-black tracking-tight">{title}</h1>
        {subtitle && <p className="text-sm text-muted-foreground">{subtitle}</p>}
      </div>
    </div>
  )
}

export function Field({
  label,
  id,
  hint,
  ...props
}: React.InputHTMLAttributes<HTMLInputElement> & { label: string; id: string; hint?: string }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-sm font-semibold text-muted-foreground">
        {label}
      </label>
      <input
        id={id}
        {...props}
        className="h-14 w-full rounded-2xl border border-input bg-card px-4 text-base text-foreground placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
      />
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
    </div>
  )
}

export function Sheet({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean
  onClose: () => void
  title: string
  children: React.ReactNode
}) {
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [open, onClose])

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" role="dialog" aria-modal="true" aria-label={title}>
      <button
        type="button"
        aria-label="Fermer"
        className="absolute inset-0 bg-black/75 backdrop-blur-sm animate-in fade-in"
        onClick={onClose}
      />
      <div className="relative max-h-[92dvh] w-full max-w-md overflow-y-auto rounded-t-[2rem] border-t border-border bg-popover p-5 pb-8 animate-in slide-in-from-bottom duration-300">
        <div className="mx-auto mb-4 h-1.5 w-12 rounded-full bg-muted-foreground/30" aria-hidden="true" />
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="text-lg font-bold">{title}</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fermer"
            className="flex size-10 items-center justify-center rounded-full bg-secondary text-foreground"
          >
            <X className="size-5" />
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}

export function SummaryRow({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-4 py-2">
      <span className={cn('text-sm', strong ? 'font-bold text-foreground' : 'text-muted-foreground')}>{label}</span>
      <span className={cn('text-right', strong ? 'text-lg font-black text-primary' : 'font-semibold text-foreground')}>
        {value}
      </span>
    </div>
  )
}
