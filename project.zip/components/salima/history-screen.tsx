'use client'

import { useState } from 'react'
import { ArrowDownLeft, ArrowUpRight, Receipt } from 'lucide-react'
import { formatDate, formatFcfa, formatOriginal, type Transaction } from '@/lib/salima'
import { cn } from '@/lib/utils'
import { useApp } from './app-provider'
import { ScreenHeader } from './primitives'
import { ReceiptSheet } from './receipt'

const FILTERS = [
  { id: 'all', label: 'Tout' },
  { id: 'FCFA', label: 'FCFA' },
  { id: 'Pi', label: 'Pi' },
  { id: 'USDT', label: 'USDT' },
  { id: 'success', label: 'Réussi' },
  { id: 'cancelled', label: 'Annulé' },
] as const

type FilterId = (typeof FILTERS)[number]['id']

function matches(tx: Transaction, filter: FilterId) {
  if (filter === 'all') return true
  if (filter === 'success' || filter === 'cancelled') return tx.status === filter
  return tx.currency === filter
}

export function HistoryScreen() {
  const { goTo, transactions, hidden } = useApp()
  const [filter, setFilter] = useState<FilterId>('all')
  const [selected, setSelected] = useState<Transaction | null>(null)
  const list = transactions.filter((tx) => matches(tx, filter))

  return (
    <div>
      <ScreenHeader title="HISTORIQUE" subtitle={`${list.length} opération(s)`} onBack={() => goTo('accueil')} />
      <div className="-mx-4 mb-4 flex gap-2 overflow-x-auto px-4 pb-1" role="tablist" aria-label="Filtres">
        {FILTERS.map((f) => (
          <button
            key={f.id}
            type="button"
            role="tab"
            aria-selected={filter === f.id}
            onClick={() => setFilter(f.id)}
            className={cn(
              'h-10 shrink-0 rounded-full px-4 text-sm font-bold transition-colors',
              filter === f.id ? 'bg-primary text-primary-foreground' : 'border border-border bg-card text-muted-foreground',
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      {list.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-3xl border border-dashed border-border py-12 text-center">
          <Receipt className="size-8 text-muted-foreground" aria-hidden="true" />
          <p className="text-muted-foreground">Aucune opération pour ce filtre.</p>
        </div>
      ) : (
        <ul className="flex flex-col gap-2">
          {list.map((tx) => (
            <li key={tx.id}>
              <button
                type="button"
                onClick={() => setSelected(tx)}
                className="flex w-full items-center gap-3 rounded-2xl border border-border bg-card p-3 text-left active:bg-secondary"
              >
                <span
                  className={cn(
                    'flex size-11 shrink-0 items-center justify-center rounded-xl',
                    tx.type === 'reception' ? 'bg-primary text-primary-foreground' : 'bg-secondary text-primary',
                  )}
                >
                  {tx.type === 'reception' ? <ArrowDownLeft className="size-5" /> : <ArrowUpRight className="size-5" />}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-semibold">{tx.label}</span>
                  <span className="block truncate text-xs text-muted-foreground">
                    {tx.counterpart} · {tx.code}
                  </span>
                  <span className="block text-xs text-muted-foreground">{formatDate(tx.date)}</span>
                </span>
                <span className="flex shrink-0 flex-col items-end gap-1">
                  <span className={cn('text-sm font-bold', tx.status === 'cancelled' && 'text-muted-foreground line-through')}>
                    {hidden ? '•••' : formatFcfa(tx.totalFcfa)}
                  </span>
                  {tx.currency !== 'FCFA' && !hidden && (
                    <span className="text-xs text-muted-foreground">{formatOriginal(tx)}</span>
                  )}
                  <span
                    className={cn(
                      'rounded-full px-2 py-0.5 text-[10px] font-bold',
                      tx.status === 'success' ? 'bg-primary/15 text-primary' : 'bg-destructive/15 text-destructive',
                    )}
                  >
                    {tx.status === 'success' ? 'Réussi' : 'Annulé'}
                  </span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
      <ReceiptSheet tx={selected} onClose={() => setSelected(null)} />
    </div>
  )
}
