'use client'

import { useState } from 'react'
import { ArrowRightLeft, Check, Droplets, Send, Smartphone, Wallet, Zap } from 'lucide-react'
import {
  PI_RATE_FCFA,
  SENDER_NAME,
  USDT_RATE_FCFA,
  formatFcfa,
  formatPi,
  formatUsdt,
  generateCode,
  type Transaction,
} from '@/lib/salima'
import { cn } from '@/lib/utils'
import { useApp } from './app-provider'
import { PinSheet } from './pin-sheet'
import { Field, PrimaryButton, ScreenHeader, Sheet, SummaryRow } from './primitives'
import { ReceiptCard } from './receipt'

type ServiceKind = 'transfer' | 'mobile' | 'bill' | 'convert'

type ServiceDef = {
  id: string
  name: string
  desc: string
  kind: ServiceKind
  icon: React.ComponentType<{ className?: string }>
  field?: { label: string; placeholder: string }
}

const SERVICES: ServiceDef[] = [
  { id: 'NITA', name: 'NITA', desc: 'Transfert national', kind: 'transfer', icon: Send },
  { id: 'AMANA', name: 'AMANA', desc: 'Transfert en agence', kind: 'transfer', icon: Send },
  { id: 'AIRTEL', name: 'Airtel Money', desc: 'Dépôt & crédit', kind: 'mobile', icon: Smartphone, field: { label: 'Numéro Airtel', placeholder: '96 00 00 00' } },
  { id: 'MOOV', name: 'Moov Money', desc: 'Dépôt & crédit', kind: 'mobile', icon: Smartphone, field: { label: 'Numéro Moov', placeholder: '99 00 00 00' } },
  { id: 'ZAMANI', name: 'Zamani', desc: 'Recharge & dépôt', kind: 'mobile', icon: Wallet, field: { label: 'Numéro Zamani', placeholder: '90 00 00 00' } },
  { id: 'NIGELEC', name: 'NIGELEC', desc: 'Facture électricité', kind: 'bill', icon: Zap, field: { label: 'N° de compteur / police', placeholder: '0412 5587' } },
  { id: 'NDE', name: 'NDE Eau', desc: 'Facture d’eau', kind: 'bill', icon: Droplets, field: { label: 'N° d’abonné', placeholder: 'NDE-000000' } },
  { id: 'CONVERT', name: 'Pi → XOF / USDT', desc: 'Conversion instantanée', kind: 'convert', icon: ArrowRightLeft },
]

export function ServicesScreen() {
  const { goTo } = useApp()
  const [active, setActive] = useState<ServiceDef | null>(null)

  return (
    <div>
      <ScreenHeader title="SERVICES" subtitle="Tous vos services en un seul endroit" onBack={() => goTo('accueil')} />
      <ul className="grid grid-cols-2 gap-3">
        {SERVICES.map((s) => (
          <li key={s.id} className={s.kind === 'convert' ? 'col-span-2' : undefined}>
            <button
              type="button"
              onClick={() => (s.kind === 'transfer' ? goTo('envoyer', { service: s.id as 'NITA' | 'AMANA' }) : setActive(s))}
              className={cn(
                'flex h-full w-full flex-col items-start gap-3 rounded-3xl border p-4 text-left transition-transform active:scale-[0.97]',
                s.kind === 'convert' ? 'border-primary bg-accent' : 'border-border bg-card',
              )}
            >
              <span className="flex size-11 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
                <s.icon className="size-5" />
              </span>
              <span>
                <span className="block font-black">{s.name}</span>
                <span className="block text-xs text-muted-foreground">{s.desc}</span>
              </span>
            </button>
          </li>
        ))}
      </ul>
      <Sheet open={active !== null} onClose={() => setActive(null)} title={active?.name ?? ''}>
        {active && (active.kind === 'convert' ? <ConvertForm onDone={() => setActive(null)} /> : <PaymentForm service={active} onDone={() => setActive(null)} />)}
      </Sheet>
    </div>
  )
}

function PaymentForm({ service, onDone }: { service: ServiceDef; onDone: () => void }) {
  const { addTransaction, piBalance } = useApp()
  const [reference, setReference] = useState('')
  const [amount, setAmount] = useState('')
  const [pinOpen, setPinOpen] = useState(false)
  const [result, setResult] = useState<Transaction | null>(null)

  const value = Math.round(Number(amount) || 0)
  const fees = value > 0 ? Math.max(50, Math.round(value * 0.01)) : 0
  const total = value + fees
  const valid = reference.trim().length >= 4 && value >= 100 && total / PI_RATE_FCFA <= piBalance

  if (result) return <Success tx={result} onDone={onDone} />

  return (
    <div className="flex flex-col gap-4">
      <Field id="ref" label={service.field?.label ?? 'Référence'} placeholder={service.field?.placeholder} value={reference} onChange={(e) => setReference(e.target.value)} />
      <Field id="amount" label="Montant (FCFA)" placeholder="5000" inputMode="numeric" value={amount} onChange={(e) => setAmount(e.target.value.replace(/\D/g, ''))} />
      <div className="rounded-2xl border border-border bg-card px-4 py-2">
        <SummaryRow label="Montant" value={formatFcfa(value)} />
        <SummaryRow label="Frais (1 %)" value={formatFcfa(fees)} />
        <SummaryRow label="Total" value={formatFcfa(total)} strong />
      </div>
      <PrimaryButton disabled={!valid} onClick={() => setPinOpen(true)}>
        Payer avec le code PIN
      </PrimaryButton>
      <PinSheet
        open={pinOpen}
        onClose={() => setPinOpen(false)}
        summary={`${service.name} · ${formatFcfa(total)}`}
        onSuccess={() => {
          const tx: Transaction = {
            id: `t${Date.now()}`,
            code: generateCode(),
            type: 'service',
            service: service.name,
            label: service.kind === 'bill' ? `Facture ${service.name}` : `Dépôt ${service.name}`,
            counterpart: reference.trim(),
            country: 'NE',
            amountFcfa: value,
            feesFcfa: fees,
            totalFcfa: total,
            currency: 'FCFA',
            amountOriginal: value,
            status: 'success',
            date: new Date().toISOString(),
            sender: SENDER_NAME,
          }
          addTransaction(tx)
          setPinOpen(false)
          setResult(tx)
        }}
      />
    </div>
  )
}

function ConvertForm({ onDone }: { onDone: () => void }) {
  const { addTransaction, piBalance } = useApp()
  const [target, setTarget] = useState<'XOF' | 'USDT'>('XOF')
  const [amount, setAmount] = useState('')
  const [pinOpen, setPinOpen] = useState(false)
  const [result, setResult] = useState<Transaction | null>(null)

  const pi = Number(amount.replace(',', '.')) || 0
  const grossFcfa = Math.round(pi * PI_RATE_FCFA)
  const fees = grossFcfa > 0 ? Math.round(grossFcfa * 0.01) : 0
  const netFcfa = grossFcfa - fees
  const usdt = netFcfa / USDT_RATE_FCFA
  const valid = pi > 0 && pi <= piBalance

  if (result) return <Success tx={result} onDone={onDone} />

  return (
    <div className="flex flex-col gap-4">
      <div className="flex rounded-2xl bg-secondary p-1" role="group" aria-label="Convertir vers">
        {(['XOF', 'USDT'] as const).map((t) => (
          <button
            key={t}
            type="button"
            aria-pressed={target === t}
            onClick={() => setTarget(t)}
            className={cn('h-11 flex-1 rounded-xl text-sm font-bold', target === t ? 'bg-primary text-primary-foreground' : 'text-muted-foreground')}
          >
            Pi → {t}
          </button>
        ))}
      </div>
      <Field
        id="pi-amount"
        label="Montant en Pi"
        placeholder="10"
        inputMode="decimal"
        value={amount}
        onChange={(e) => setAmount(e.target.value.replace(/[^\d.,]/g, ''))}
        hint={`Disponible : ${formatPi(piBalance)} · 1 Pi = ${formatFcfa(PI_RATE_FCFA)} · 1 USDT = ${formatFcfa(USDT_RATE_FCFA)}`}
      />
      <div className="rounded-2xl border border-border bg-card px-4 py-2">
        <SummaryRow label="Valeur" value={formatFcfa(grossFcfa)} />
        <SummaryRow label="Frais (1 %)" value={formatFcfa(fees)} />
        <SummaryRow label="Vous recevez" value={target === 'XOF' ? formatFcfa(netFcfa) : formatUsdt(usdt)} strong />
      </div>
      <PrimaryButton disabled={!valid} onClick={() => setPinOpen(true)}>
        Convertir
      </PrimaryButton>
      <PinSheet
        open={pinOpen}
        onClose={() => setPinOpen(false)}
        summary={`${formatPi(pi)} → ${target === 'XOF' ? formatFcfa(netFcfa) : formatUsdt(usdt)}`}
        onSuccess={() => {
          const tx: Transaction = {
            id: `t${Date.now()}`,
            code: generateCode(),
            type: 'service',
            service: `Pi → ${target}`,
            label: `Conversion Pi → ${target}`,
            counterpart: target === 'XOF' ? 'Portefeuille FCFA' : 'Portefeuille USDT',
            country: 'NE',
            amountFcfa: netFcfa,
            feesFcfa: fees,
            totalFcfa: grossFcfa,
            currency: target === 'USDT' ? 'USDT' : 'Pi',
            amountOriginal: target === 'USDT' ? Math.round(usdt * 100) / 100 : pi,
            status: 'success',
            date: new Date().toISOString(),
            sender: SENDER_NAME,
          }
          addTransaction(tx)
          setPinOpen(false)
          setResult(tx)
        }}
      />
    </div>
  )
}

function Success({ tx, onDone }: { tx: Transaction; onDone: () => void }) {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-center gap-2 text-primary">
        <Check className="size-6" strokeWidth={3} aria-hidden="true" />
        <p className="font-bold">Opération réussie</p>
      </div>
      <ReceiptCard tx={tx} />
      <PrimaryButton onClick={onDone}>Terminer</PrimaryButton>
    </div>
  )
}
