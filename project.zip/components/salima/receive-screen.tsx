'use client'

import { MessageCircle, MessageSquare, ShieldCheck, Store } from 'lucide-react'
import { AGENCY, buildBeneficiaryMessage, countryName, formatFcfa, INITIAL_TRANSACTIONS } from '@/lib/salima'
import { useApp } from './app-provider'
import { PrimaryButton, ScreenHeader } from './primitives'
import { shareOnWhatsApp } from './receipt'

export function ReceiveScreen() {
  const { goTo, lastTransfer } = useApp()
  const tx = lastTransfer ?? INITIAL_TRANSACTIONS[0]
  const location = tx.city ? `${tx.city}, ${countryName(tx.country)}` : countryName(tx.country)
  const smsText = `SALIMA: Vous avez recu ${formatFcfa(tx.amountFcfa)} de ${tx.sender}. Code: ${tx.code}. Retrait: ${location}. Info ${AGENCY.phoneDisplay}`

  return (
    <div className="flex flex-col gap-5">
      <ScreenHeader title="RECEVOIR" subtitle="Comment le bénéficiaire reçoit l’argent" onBack={() => goTo('accueil')} />

      <ol className="grid grid-cols-3 gap-2 text-center text-xs">
        {[
          { icon: MessageSquare, label: 'SMS + WhatsApp avec le code' },
          { icon: Store, label: 'Se rendre en agence' },
          { icon: ShieldCheck, label: 'Code + pièce d’identité' },
        ].map((s, i) => (
          <li key={s.label} className="flex flex-col items-center gap-2 rounded-2xl border border-border bg-card p-3">
            <span className="flex size-9 items-center justify-center rounded-full bg-primary text-primary-foreground">
              <s.icon className="size-4" aria-hidden="true" />
            </span>
            <span className="font-bold text-primary">Étape {i + 1}</span>
            <span className="text-muted-foreground">{s.label}</span>
          </li>
        ))}
      </ol>

      <section aria-labelledby="sms-title">
        <h2 id="sms-title" className="mb-2 flex items-center gap-2 text-sm font-bold">
          <MessageSquare className="size-4 text-primary" aria-hidden="true" /> Message SMS
        </h2>
        <div className="rounded-3xl border border-border bg-card p-4">
          <p className="mb-2 text-xs font-semibold text-muted-foreground">De : SALIMA</p>
          <p className="rounded-2xl rounded-tl-sm bg-secondary p-3 text-sm leading-relaxed">{smsText}</p>
        </div>
      </section>

      <section aria-labelledby="wa-title">
        <h2 id="wa-title" className="mb-2 flex items-center gap-2 text-sm font-bold">
          <MessageCircle className="size-4 text-primary" aria-hidden="true" /> Message WhatsApp
        </h2>
        <div className="rounded-3xl border border-border bg-[#0b1410] p-4">
          <div className="mb-3 flex items-center gap-2">
            <span className="flex size-9 items-center justify-center rounded-full bg-primary text-sm font-black text-primary-foreground">S</span>
            <div>
              <p className="text-sm font-bold">Salima Transfert</p>
              <p className="text-xs text-muted-foreground">+227 {AGENCY.phoneDisplay}</p>
            </div>
          </div>
          <div className="ml-auto max-w-[92%] whitespace-pre-line rounded-2xl rounded-tr-sm bg-[#1f3a12] p-3 text-sm leading-relaxed">
            {buildBeneficiaryMessage(tx)}
          </div>
        </div>
      </section>

      <section className="grid grid-cols-2 gap-3">
        <InfoTile label="Code" value={tx.code} mono />
        <InfoTile label="Montant" value={formatFcfa(tx.amountFcfa)} />
        <InfoTile label="Expéditeur" value={tx.sender} />
        <InfoTile label="Ville" value={location} />
      </section>

      <PrimaryButton onClick={() => shareOnWhatsApp(tx)}>
        <MessageCircle className="size-5" />
        Partager le reçu sur WhatsApp
      </PrimaryButton>
    </div>
  )
}

function InfoTile({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={mono ? 'font-mono text-lg font-black text-primary' : 'truncate font-bold'}>{value}</p>
    </div>
  )
}
