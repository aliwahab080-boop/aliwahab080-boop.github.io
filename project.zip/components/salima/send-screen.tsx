'use client'

import { useMemo, useState } from 'react'
import { Check, ChevronRight, MapPin, MessageCircle, Search } from 'lucide-react'
import {
  COUNTRIES,
  NIGER_CITIES,
  PI_RATE_FCFA,
  SENDER_NAME,
  computeFees,
  countryName,
  formatFcfa,
  formatPi,
  generateCode,
  normalize,
  type Transaction,
  type TransferService,
} from '@/lib/salima'
import { cn } from '@/lib/utils'
import { useApp } from './app-provider'
import { PinSheet } from './pin-sheet'
import { Field, PrimaryButton, ScreenHeader, SecondaryButton, SummaryRow } from './primitives'
import { ReceiptCard, shareOnWhatsApp } from './receipt'

type Step = 'service' | 'pays' | 'ville' | 'details' | 'resume' | 'succes'

const SERVICES: { id: TransferService; desc: string }[] = [
  { id: 'NITA', desc: 'Réseau national rapide · frais 1,5 %' },
  { id: 'AMANA', desc: 'Retrait en agence partout · frais 1 %' },
]

export function SendScreen() {
  const { goTo, presetService, piBalance, addTransaction } = useApp()
  const [step, setStep] = useState<Step>(presetService ? 'pays' : 'service')
  const [service, setService] = useState<TransferService | null>(presetService)
  const [country, setCountry] = useState<string | null>(null)
  const [city, setCity] = useState<string | null>(null)
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [currency, setCurrency] = useState<'FCFA' | 'Pi'>('FCFA')
  const [amount, setAmount] = useState('')
  const [pinOpen, setPinOpen] = useState(false)
  const [result, setResult] = useState<Transaction | null>(null)

  const international = country !== null && country !== 'NE'
  const numericAmount = Number(amount.replace(',', '.')) || 0
  const amountFcfa = currency === 'Pi' ? Math.round(numericAmount * PI_RATE_FCFA) : Math.round(numericAmount)
  const fees = service ? computeFees(amountFcfa, service, international) : 0
  const total = amountFcfa + fees
  const totalPi = total / PI_RATE_FCFA
  const insufficient = totalPi > piBalance
  const detailsValid = name.trim().length >= 2 && phone.replace(/\D/g, '').length >= 8 && amountFcfa >= 500 && !insufficient

  const back = () => {
    const order: Step[] = ['service', 'pays', 'ville', 'details', 'resume']
    if (step === 'service' || step === 'succes') return goTo('accueil')
    if (step === 'details' && international) return setStep('pays')
    setStep(order[order.indexOf(step) - 1])
  }

  const confirm = () => {
    if (!service || !country) return
    const tx: Transaction = {
      id: `t${Date.now()}`,
      code: generateCode(),
      type: 'envoi',
      service,
      label: international ? 'Envoi international' : `Envoi ${service}`,
      counterpart: name.trim(),
      phone: phone.trim(),
      country,
      city: international ? undefined : city ?? undefined,
      amountFcfa,
      feesFcfa: fees,
      totalFcfa: total,
      currency,
      amountOriginal: numericAmount,
      status: 'success',
      date: new Date().toISOString(),
      sender: SENDER_NAME,
    }
    addTransaction(tx)
    setResult(tx)
    setPinOpen(false)
    setStep('succes')
  }

  const titles: Record<Step, string> = {
    service: 'Choisir le service',
    pays: 'Pays de destination',
    ville: 'Ville ou village',
    details: 'Bénéficiaire',
    resume: 'Récapitulatif',
    succes: 'Envoi réussi',
  }

  return (
    <div>
      <ScreenHeader
        title={titles[step]}
        subtitle={step !== 'succes' ? 'ENVOYER' : undefined}
        onBack={step === 'succes' ? undefined : back}
      />
      {step !== 'succes' && <Progress step={step} />}

      {step === 'service' && (
        <div className="flex flex-col gap-3">
          {SERVICES.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => {
                setService(s.id)
                setStep('pays')
              }}
              className={cn(
                'flex items-center gap-4 rounded-3xl border p-5 text-left transition-colors active:scale-[0.99]',
                service === s.id ? 'border-primary bg-accent' : 'border-border bg-card',
              )}
            >
              <span className="flex size-14 items-center justify-center rounded-2xl bg-primary text-lg font-black text-primary-foreground">
                {s.id.slice(0, 2)}
              </span>
              <span className="flex-1">
                <span className="block text-xl font-black">{s.id}</span>
                <span className="block text-sm text-muted-foreground">{s.desc}</span>
              </span>
              <ChevronRight className="size-5 text-primary" />
            </button>
          ))}
        </div>
      )}

      {step === 'pays' && (
        <CountryPicker
          selected={country}
          onSelect={(code) => {
            setCountry(code)
            if (code === 'NE') {
              setStep('ville')
            } else {
              setCity(null)
              setStep('details')
            }
          }}
        />
      )}

      {step === 'ville' && (
        <CityPicker
          selected={city}
          onSelect={(c) => {
            setCity(c)
            setStep('details')
          }}
        />
      )}

      {step === 'details' && (
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-2 rounded-2xl border border-border bg-card px-4 py-3 text-sm">
            <MapPin className="size-4 text-primary" aria-hidden="true" />
            <span className="text-muted-foreground">Destination :</span>
            <span className="font-semibold">
              {city ? `${city}, ` : ''}
              {country ? countryName(country) : ''}
            </span>
            <span className="ml-auto rounded-full bg-primary/15 px-2 py-0.5 text-xs font-bold text-primary">{service}</span>
          </div>
          <Field
            id="beneficiaire"
            label="Nom du bénéficiaire"
            placeholder="Ex : Moussa Issoufou"
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoComplete="name"
          />
          <Field
            id="telephone"
            label="Téléphone du bénéficiaire"
            placeholder={international ? '+33 6 12 34 56 78' : '96 12 45 78'}
            inputMode="tel"
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <label htmlFor="montant" className="text-sm font-semibold text-muted-foreground">
                Montant
              </label>
              <div className="flex rounded-full bg-secondary p-1" role="group" aria-label="Devise">
                {(['FCFA', 'Pi'] as const).map((c) => (
                  <button
                    key={c}
                    type="button"
                    aria-pressed={currency === c}
                    onClick={() => setCurrency(c)}
                    className={cn(
                      'rounded-full px-4 py-1 text-xs font-bold',
                      currency === c ? 'bg-primary text-primary-foreground' : 'text-muted-foreground',
                    )}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
            <div className="relative">
              <input
                id="montant"
                inputMode="decimal"
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value.replace(/[^\d.,]/g, ''))}
                className="h-16 w-full rounded-2xl border border-input bg-card px-4 pr-20 text-2xl font-black text-foreground placeholder:text-muted-foreground/50 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 font-bold text-primary">{currency}</span>
            </div>
            <p className="text-xs text-muted-foreground">
              {currency === 'Pi' ? `≈ ${formatFcfa(amountFcfa)}` : `≈ ${formatPi(amountFcfa / PI_RATE_FCFA)}`} · Minimum 500 FCFA
            </p>
          </div>

          <div className="rounded-2xl border border-border bg-card px-4 py-2">
            <SummaryRow label="Montant" value={formatFcfa(amountFcfa)} />
            <SummaryRow label={`Frais ${international ? '(international 3 %)' : service ?? ''}`} value={formatFcfa(fees)} />
            <div className="border-t border-border" />
            <SummaryRow label="Total" value={formatFcfa(total)} strong />
            <p className="pb-2 text-right text-xs text-muted-foreground">soit {formatPi(totalPi)} débités</p>
          </div>
          {insufficient && (
            <p role="alert" className="text-sm font-medium text-destructive">
              Solde Pi insuffisant pour ce montant.
            </p>
          )}
          <PrimaryButton disabled={!detailsValid} onClick={() => setStep('resume')}>
            Continuer
          </PrimaryButton>
        </div>
      )}

      {step === 'resume' && (
        <div className="flex flex-col gap-4">
          <div className="rounded-3xl border border-border bg-card px-4 py-2">
            <SummaryRow label="Service" value={service ?? ''} />
            <SummaryRow label="Pays" value={country ? countryName(country) : ''} />
            {city && !international && <SummaryRow label="Ville" value={city} />}
            <SummaryRow label="Bénéficiaire" value={name} />
            <SummaryRow label="Téléphone" value={phone} />
            {currency === 'Pi' && <SummaryRow label="Montant saisi" value={formatPi(numericAmount)} />}
            <SummaryRow label="Montant" value={formatFcfa(amountFcfa)} />
            <SummaryRow label="Frais" value={formatFcfa(fees)} />
            <div className="border-t border-border" />
            <SummaryRow label="Total à payer" value={formatFcfa(total)} strong />
          </div>
          <p className="text-center text-xs text-muted-foreground">
            Le bénéficiaire recevra un SMS et un message WhatsApp avec le code de retrait.
          </p>
          <PrimaryButton onClick={() => setPinOpen(true)}>Confirmer avec le code PIN</PrimaryButton>
          <SecondaryButton onClick={() => setStep('details')}>Modifier</SecondaryButton>
        </div>
      )}

      {step === 'succes' && result && (
        <div className="flex flex-col gap-4">
          <div className="flex flex-col items-center gap-2 py-2 text-center">
            <span className="flex size-16 items-center justify-center rounded-full bg-primary text-primary-foreground animate-in zoom-in">
              <Check className="size-8" strokeWidth={3} />
            </span>
            <p className="text-muted-foreground">
              {formatFcfa(result.amountFcfa)} envoyés à <span className="font-semibold text-foreground">{result.counterpart}</span>
            </p>
          </div>
          <ReceiptCard tx={result} />
          <PrimaryButton onClick={() => shareOnWhatsApp(result)}>
            <MessageCircle className="size-5" />
            Partager le reçu sur WhatsApp
          </PrimaryButton>
          <SecondaryButton onClick={() => goTo('recevoir')}>Voir le message du bénéficiaire</SecondaryButton>
          <SecondaryButton onClick={() => goTo('accueil')}>Retour à l&apos;accueil</SecondaryButton>
        </div>
      )}

      <PinSheet
        open={pinOpen}
        onClose={() => setPinOpen(false)}
        onSuccess={confirm}
        summary={`Total : ${formatFcfa(total)} vers ${name}`}
      />
    </div>
  )
}

function Progress({ step }: { step: Step }) {
  const steps: Step[] = ['service', 'pays', 'ville', 'details', 'resume']
  const index = steps.indexOf(step)
  return (
    <div className="mb-5 flex gap-1.5" aria-label={`Étape ${index + 1} sur ${steps.length}`}>
      {steps.map((s, i) => (
        <span key={s} className={cn('h-1.5 flex-1 rounded-full', i <= index ? 'bg-primary' : 'bg-secondary')} />
      ))}
    </div>
  )
}

function SearchInput({ value, onChange, placeholder, label }: { value: string; onChange: (v: string) => void; placeholder: string; label: string }) {
  return (
    <div className="relative mb-3">
      <Search className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
      <label className="sr-only" htmlFor={`search-${label}`}>
        {label}
      </label>
      <input
        id={`search-${label}`}
        type="search"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="h-14 w-full rounded-2xl border border-input bg-card pl-12 pr-4 text-base text-foreground placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
      />
    </div>
  )
}

function OptionButton({ selected, onClick, children, badge }: { selected: boolean; onClick: () => void; children: React.ReactNode; badge?: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'flex w-full items-center gap-3 rounded-2xl border px-4 py-3.5 text-left font-semibold transition-colors',
        selected ? 'border-primary bg-accent text-accent-foreground' : 'border-border bg-card text-foreground active:bg-secondary',
      )}
    >
      {badge && (
        <span className="flex h-7 w-9 shrink-0 items-center justify-center rounded-md bg-secondary font-mono text-xs font-bold text-primary">
          {badge}
        </span>
      )}
      <span className="flex-1">{children}</span>
      {selected ? <Check className="size-5 text-primary" /> : <ChevronRight className="size-4 text-muted-foreground" />}
    </button>
  )
}

function CountryPicker({ selected, onSelect }: { selected: string | null; onSelect: (code: string) => void }) {
  const [query, setQuery] = useState('')
  const filtered = useMemo(() => {
    const q = normalize(query.trim())
    return q ? COUNTRIES.filter((c) => normalize(c.name).includes(q) || c.code.toLowerCase() === q) : COUNTRIES
  }, [query])
  const priority = filtered.filter((c) => c.priority)
  const others = filtered.filter((c) => !c.priority)

  return (
    <div>
      <SearchInput value={query} onChange={setQuery} placeholder="Rechercher un pays..." label="pays" />
      {filtered.length === 0 && <p className="py-6 text-center text-muted-foreground">Aucun pays trouvé.</p>}
      {priority.length > 0 && (
        <>
          <p className="mb-2 text-xs font-bold uppercase tracking-widest text-muted-foreground">Populaires</p>
          <ul className="mb-4 flex flex-col gap-2">
            {priority.map((c) => (
              <li key={c.code}>
                <OptionButton selected={selected === c.code} onClick={() => onSelect(c.code)} badge={c.code}>
                  {c.name}
                </OptionButton>
              </li>
            ))}
          </ul>
        </>
      )}
      {others.length > 0 && (
        <>
          <p className="mb-2 text-xs font-bold uppercase tracking-widest text-muted-foreground">Tous les pays</p>
          <ul className="flex flex-col gap-2">
            {others.map((c) => (
              <li key={c.code}>
                <OptionButton selected={selected === c.code} onClick={() => onSelect(c.code)} badge={c.code}>
                  {c.name}
                </OptionButton>
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  )
}

function CityPicker({ selected, onSelect }: { selected: string | null; onSelect: (city: string) => void }) {
  const [query, setQuery] = useState('')
  const trimmed = query.trim()
  const filtered = useMemo(() => {
    const q = normalize(trimmed)
    return q ? NIGER_CITIES.filter((c) => normalize(c).includes(q)) : NIGER_CITIES
  }, [trimmed])
  const exact = NIGER_CITIES.some((c) => normalize(c) === normalize(trimmed))

  return (
    <div>
      <SearchInput value={query} onChange={setQuery} placeholder="Rechercher une ville ou un village..." label="ville" />
      {trimmed.length >= 2 && !exact && (
        <button
          type="button"
          onClick={() => onSelect(trimmed.charAt(0).toUpperCase() + trimmed.slice(1))}
          className="mb-3 flex w-full items-center gap-3 rounded-2xl bg-primary px-4 py-3.5 text-left font-bold text-primary-foreground"
        >
          <MapPin className="size-5" aria-hidden="true" />
          Utiliser le village « {trimmed} »
        </button>
      )}
      <ul className="grid grid-cols-2 gap-2">
        {filtered.map((c) => (
          <li key={c}>
            <button
              type="button"
              onClick={() => onSelect(c)}
              className={cn(
                'flex h-12 w-full items-center justify-center rounded-2xl border px-2 text-center text-sm font-semibold',
                selected === c ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card text-foreground active:bg-secondary',
              )}
            >
              {c}
            </button>
          </li>
        ))}
      </ul>
    </div>
  )
}
