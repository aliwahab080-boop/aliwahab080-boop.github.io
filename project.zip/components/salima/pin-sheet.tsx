'use client'

import { useState } from 'react'
import { Delete, Lock } from 'lucide-react'
import { PIN_CODE } from '@/lib/salima'
import { cn } from '@/lib/utils'
import { Sheet } from './primitives'

export function PinSheet({
  open,
  onClose,
  onSuccess,
  summary,
}: {
  open: boolean
  onClose: () => void
  onSuccess: () => void
  summary?: string
}) {
  const [pin, setPin] = useState('')
  const [error, setError] = useState('')

  const close = () => {
    setPin('')
    setError('')
    onClose()
  }

  const press = (digit: string) => {
    if (pin.length >= 4) return
    const next = pin + digit
    setError('')
    setPin(next)
    if (next.length === 4) {
      setTimeout(() => {
        if (next === PIN_CODE) {
          setPin('')
          onSuccess()
        } else {
          setError('Code PIN incorrect. Réessayez.')
          setPin('')
        }
      }, 180)
    }
  }

  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9']

  return (
    <Sheet open={open} onClose={close} title="Confirmation">
      <div className="flex flex-col items-center gap-5">
        <div className="flex size-14 items-center justify-center rounded-full bg-accent text-primary">
          <Lock className="size-6" aria-hidden="true" />
        </div>
        <div className="text-center">
          <p className="font-semibold">Entrez votre code PIN</p>
          {summary && <p className="mt-1 text-sm text-muted-foreground">{summary}</p>}
          <p className="mt-1 text-xs text-muted-foreground">Code de démonstration : 1234</p>
        </div>
        <div className="flex gap-4" aria-live="polite" aria-label={`${pin.length} chiffres saisis sur 4`}>
          {[0, 1, 2, 3].map((i) => (
            <span
              key={i}
              className={cn(
                'size-4 rounded-full border-2 transition-colors',
                i < pin.length ? 'border-primary bg-primary' : 'border-muted-foreground/40',
                error && 'border-destructive',
              )}
            />
          ))}
        </div>
        <p role="alert" className="min-h-5 text-sm font-medium text-destructive">
          {error}
        </p>
        <div className="grid w-full grid-cols-3 gap-3">
          {keys.map((k) => (
            <PinKey key={k} onClick={() => press(k)}>
              {k}
            </PinKey>
          ))}
          <span aria-hidden="true" />
          <PinKey onClick={() => press('0')}>0</PinKey>
          <PinKey onClick={() => setPin((p) => p.slice(0, -1))} aria-label="Effacer">
            <Delete className="size-6" />
          </PinKey>
        </div>
      </div>
    </Sheet>
  )
}

function PinKey(props: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      {...props}
      className="flex h-16 items-center justify-center rounded-2xl bg-secondary text-2xl font-bold text-foreground transition-colors active:bg-primary active:text-primary-foreground"
    />
  )
}
