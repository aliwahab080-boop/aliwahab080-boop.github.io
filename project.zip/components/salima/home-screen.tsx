'use client'

import { ArrowDownLeft, ArrowUpRight, Eye, EyeOff, History, MapPin, MessageCircle, Phone, TrendingUp } from 'lucide-react'
import { AGENCY, PI_RATE_FCFA, formatDate, formatFcfa, formatPi } from '@/lib/salima'
import { cn } from '@/lib/utils'
import { useApp } from './app-provider'

export function HomeScreen() {
  const { piBalance, fcfaBalance, hidden, toggleHidden, goTo, transactions } = useApp()
  const recent = transactions.slice(0, 3)
  const mask = '••••••'

  return (
    <div className="flex flex-col gap-5">
      <section className="flex items-center gap-2 text-sm text-muted-foreground">
        <MapPin className="size-4 text-primary" aria-hidden="true" />
        <span>
          {AGENCY.city} · <a href={`tel:${AGENCY.phoneIntl}`} className="font-semibold text-foreground">{AGENCY.phoneDisplay}</a>
        </span>
      </section>

      <section
        aria-label="Solde"
        className="relative overflow-hidden rounded-[2rem] bg-primary p-6 text-primary-foreground"
      >
        <div className="absolute -right-10 -top-10 size-40 rounded-full bg-black/10" aria-hidden="true" />
        <div className="absolute -bottom-16 -right-4 size-44 rounded-full bg-black/10" aria-hidden="true" />
        <div className="relative flex items-start justify-between gap-3">
          <p className="text-sm font-semibold opacity-80">Solde Pi</p>
          <button
            type="button"
            onClick={toggleHidden}
            aria-pressed={hidden}
            className="inline-flex items-center gap-1.5 rounded-full bg-black px-3 py-1.5 text-xs font-bold text-primary"
          >
            {hidden ? <Eye className="size-4" /> : <EyeOff className="size-4" />}
            {hidden ? 'AFFICHER' : 'MASQUER'}
          </button>
        </div>
        <p className="relative mt-1 text-4xl font-black tracking-tight">{hidden ? `${mask} Pi` : formatPi(piBalance)}</p>
        <div className="relative mt-4 rounded-2xl bg-black/15 px-4 py-3">
          <p className="text-xs font-semibold opacity-80">Équivalent FCFA</p>
          <p className="text-xl font-black">{hidden ? `${mask} FCFA` : formatFcfa(fcfaBalance)}</p>
        </div>
      </section>

      <section className="flex items-center justify-between rounded-2xl border border-border bg-card px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-xl bg-accent text-primary">
            <TrendingUp className="size-5" aria-hidden="true" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Taux du jour</p>
            <p className="font-bold">1 Pi = {formatFcfa(PI_RATE_FCFA)}</p>
          </div>
        </div>
        <span className="rounded-full bg-primary/15 px-2.5 py-1 text-xs font-bold text-primary">EN DIRECT</span>
      </section>

      <section aria-label="Actions" className="grid grid-cols-3 gap-3">
        <ActionTile label="ENVOYER" icon={ArrowUpRight} primary onClick={() => goTo('envoyer')} />
        <ActionTile label="RECEVOIR" icon={ArrowDownLeft} onClick={() => goTo('recevoir')} />
        <ActionTile label="HISTORIQUE" icon={History} onClick={() => goTo('historique')} />
      </section>

      <section className="grid grid-cols-2 gap-3">
        <a
          href={`https://wa.me/${AGENCY.whatsapp}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex h-14 items-center justify-center gap-2 rounded-2xl bg-primary font-bold text-primary-foreground active:scale-[0.98]"
        >
          <MessageCircle className="size-5" aria-hidden="true" />
          WhatsApp
        </a>
        <a
          href={`tel:${AGENCY.phoneIntl}`}
          className="flex h-14 items-center justify-center gap-2 rounded-2xl border border-primary font-bold text-primary active:scale-[0.98]"
        >
          <Phone className="size-5" aria-hidden="true" />
          Appeler
        </a>
      </section>

      <section>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-bold">Activité récente</h2>
          <button type="button" onClick={() => goTo('historique')} className="text-sm font-semibold text-primary">
            Tout voir
          </button>
        </div>
        <ul className="flex flex-col gap-2">
          {recent.map((tx) => (
            <li key={tx.id} className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3">
              <div
                className={cn(
                  'flex size-10 shrink-0 items-center justify-center rounded-xl',
                  tx.type === 'reception' ? 'bg-primary text-primary-foreground' : 'bg-secondary text-primary',
                )}
              >
                {tx.type === 'reception' ? <ArrowDownLeft className="size-5" /> : <ArrowUpRight className="size-5" />}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold">{tx.counterpart}</p>
                <p className="truncate text-xs text-muted-foreground">
                  {tx.service} · {formatDate(tx.date)}
                </p>
              </div>
              <p className={cn('shrink-0 text-sm font-bold', tx.status === 'cancelled' && 'text-muted-foreground line-through')}>
                {hidden ? '•••' : `${tx.type === 'reception' ? '+' : '-'}${formatFcfa(tx.amountFcfa)}`}
              </p>
            </li>
          ))}
        </ul>
      </section>
    </div>
  )
}

function ActionTile({
  label,
  icon: Icon,
  onClick,
  primary,
}: {
  label: string
  icon: React.ComponentType<{ className?: string }>
  onClick: () => void
  primary?: boolean
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'flex flex-col items-center justify-center gap-2 rounded-2xl py-4 text-[11px] font-black tracking-wide transition-transform active:scale-95',
        primary ? 'bg-primary text-primary-foreground' : 'border border-border bg-card text-foreground',
      )}
    >
      <span
        className={cn(
          'flex size-11 items-center justify-center rounded-full',
          primary ? 'bg-black text-primary' : 'bg-primary text-primary-foreground',
        )}
      >
        <Icon className="size-5" />
      </span>
      {label}
    </button>
  )
}
