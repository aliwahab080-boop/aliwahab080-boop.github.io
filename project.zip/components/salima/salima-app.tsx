'use client'

import { ArrowDownLeft, ArrowUpRight, History, Home, LayoutGrid, Phone } from 'lucide-react'
import { AGENCY } from '@/lib/salima'
import { cn } from '@/lib/utils'
import { AppProvider, useApp, type Screen } from './app-provider'
import { HistoryScreen } from './history-screen'
import { HomeScreen } from './home-screen'
import { Logo } from './primitives'
import { ReceiveScreen } from './receive-screen'
import { SendScreen } from './send-screen'
import { ServicesScreen } from './services-screen'

export function SalimaApp() {
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  )
}

const NAV: { id: Screen; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'accueil', label: 'Accueil', icon: Home },
  { id: 'envoyer', label: 'Envoyer', icon: ArrowUpRight },
  { id: 'recevoir', label: 'Recevoir', icon: ArrowDownLeft },
  { id: 'services', label: 'Services', icon: LayoutGrid },
  { id: 'historique', label: 'Historique', icon: History },
]

function Shell() {
  const { screen, goTo } = useApp()

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col bg-background">
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-border bg-background/90 px-4 py-3 backdrop-blur">
        <button type="button" onClick={() => goTo('accueil')} aria-label="Accueil Salima Transfert">
          <Logo />
        </button>
        <a
          href={`tel:${AGENCY.phoneIntl}`}
          aria-label={`Appeler ${AGENCY.phoneDisplay}`}
          className="flex size-11 items-center justify-center rounded-full bg-primary text-primary-foreground"
        >
          <Phone className="size-5" />
        </a>
      </header>

      <main className="flex-1 px-4 pb-28 pt-5">
        {screen === 'accueil' && <HomeScreen />}
        {screen === 'envoyer' && <SendScreen />}
        {screen === 'recevoir' && <ReceiveScreen />}
        {screen === 'services' && <ServicesScreen />}
        {screen === 'historique' && <HistoryScreen />}
      </main>

      <nav
        aria-label="Navigation principale"
        className="fixed inset-x-0 bottom-0 z-40 mx-auto w-full max-w-md border-t border-border bg-black/95 px-2 pb-[max(env(safe-area-inset-bottom),0.5rem)] pt-2 backdrop-blur"
      >
        <ul className="grid grid-cols-5">
          {NAV.map((item) => {
            const active = screen === item.id
            return (
              <li key={item.id}>
                <button
                  type="button"
                  onClick={() => goTo(item.id)}
                  aria-current={active ? 'page' : undefined}
                  className="flex w-full flex-col items-center gap-1 py-1 text-[11px] font-semibold"
                >
                  <span
                    className={cn(
                      'flex h-8 w-12 items-center justify-center rounded-full transition-colors',
                      active ? 'bg-primary text-primary-foreground' : 'text-muted-foreground',
                    )}
                  >
                    <item.icon className="size-5" />
                  </span>
                  <span className={active ? 'text-primary' : 'text-muted-foreground'}>{item.label}</span>
                </button>
              </li>
            )
          })}
        </ul>
      </nav>
    </div>
  )
}
