'use client'

import { createContext, useCallback, useContext, useMemo, useState } from 'react'
import { INITIAL_TRANSACTIONS, PI_RATE_FCFA, type Transaction, type TransferService } from '@/lib/salima'

export type Screen = 'accueil' | 'envoyer' | 'recevoir' | 'services' | 'historique'

type AppState = {
  screen: Screen
  goTo: (screen: Screen, options?: { service?: TransferService }) => void
  presetService: TransferService | null
  piBalance: number
  fcfaBalance: number
  hidden: boolean
  toggleHidden: () => void
  transactions: Transaction[]
  addTransaction: (tx: Transaction) => void
  lastTransfer: Transaction | null
}

const AppContext = createContext<AppState | null>(null)

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [screen, setScreen] = useState<Screen>('accueil')
  const [presetService, setPresetService] = useState<TransferService | null>(null)
  const [piBalance, setPiBalance] = useState(125.5)
  const [hidden, setHidden] = useState(false)
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS)

  const goTo = useCallback((next: Screen, options?: { service?: TransferService }) => {
    setPresetService(options?.service ?? null)
    setScreen(next)
    window.scrollTo({ top: 0 })
  }, [])

  const addTransaction = useCallback((tx: Transaction) => {
    setTransactions((prev) => [tx, ...prev])
    if (tx.status === 'success' && tx.type !== 'reception') {
      setPiBalance((prev) => Math.max(0, Math.round((prev - tx.totalFcfa / PI_RATE_FCFA) * 100) / 100))
    }
  }, [])

  const value = useMemo<AppState>(() => {
    const lastTransfer = transactions.find((tx) => tx.type === 'envoi' && tx.status === 'success') ?? null
    return {
      screen,
      goTo,
      presetService,
      piBalance,
      fcfaBalance: piBalance * PI_RATE_FCFA,
      hidden,
      toggleHidden: () => setHidden((h) => !h),
      transactions,
      addTransaction,
      lastTransfer,
    }
  }, [screen, goTo, presetService, piBalance, hidden, transactions, addTransaction])

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used inside AppProvider')
  return ctx
}
