'use client'

import { CheckCircle2, MessageCircle, XCircle } from 'lucide-react'
import {
  AGENCY,
  buildBeneficiaryMessage,
  countryName,
  formatDate,
  formatFcfa,
  formatOriginal,
  type Transaction,
} from '@/lib/salima'
import { cn } from '@/lib/utils'
import { Logo, PrimaryButton, Sheet } from './primitives'

export function shareOnWhatsApp(tx: Transaction) {
  const text = encodeURIComponent(buildBeneficiaryMessage(tx))
  window.open(`https://wa.me/?text=${text}`, '_blank', 'noopener,noreferrer')
}

export function ReceiptCard({ tx }: { tx: Transaction }) {
  const success = tx.status === 'success'
  const location = tx.city ? `${tx.city}, ${countryName(tx.country)}` : countryName(tx.country)

  return (
    <article className="overflow-hidden rounded-3xl border border-border bg-card">
      <div className="flex items-center justify-between gap-3 border-b border-dashed border-border bg-black/40 p-4">
        <Logo size="sm" />
        <span
          className={cn(
            'inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-bold',
            success ? 'bg-primary/15 text-primary' : 'bg-destructive/15 text-destructive',
          )}
        >
          {success ? <CheckCircle2 className="size-3.5" /> : <XCircle className="size-3.5" />}
          {success ? 'Réussi' : 'Annulé'}
        </span>
      </div>
      <div className="p-4">
        <p className="text-xs uppercase tracking-widest text-muted-foreground">Code de retrait</p>
        <p className="font-mono text-3xl font-black tracking-wider text-primary">{tx.code}</p>
        <dl className="mt-4 divide-y divide-border text-sm">
          <ReceiptRow label="Date" value={formatDate(tx.date)} />
          <ReceiptRow label="Opération" value={tx.label} />
          <ReceiptRow label="Service" value={tx.service} />
          <ReceiptRow label={tx.type === 'reception' ? 'Expéditeur' : 'Bénéficiaire'} value={tx.counterpart} />
          {tx.phone && <ReceiptRow label="Téléphone" value={tx.phone} />}
          <ReceiptRow label="Destination" value={location} />
          {tx.currency !== 'FCFA' && <ReceiptRow label="Montant saisi" value={formatOriginal(tx)} />}
          <ReceiptRow label="Montant" value={formatFcfa(tx.amountFcfa)} />
          <ReceiptRow label="Frais" value={formatFcfa(tx.feesFcfa)} />
        </dl>
        <div className="mt-3 flex items-center justify-between rounded-2xl bg-primary px-4 py-3 text-primary-foreground">
          <span className="text-sm font-bold">TOTAL</span>
          <span className="text-xl font-black">{formatFcfa(tx.totalFcfa)}</span>
        </div>
        <p className="mt-4 text-center text-xs text-muted-foreground">
          {AGENCY.name} - {AGENCY.city} - {AGENCY.phoneDisplay}
        </p>
      </div>
    </article>
  )
}

function ReceiptRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-4 py-2">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="text-right font-semibold">{value}</dd>
    </div>
  )
}

export function ReceiptSheet({ tx, onClose }: { tx: Transaction | null; onClose: () => void }) {
  return (
    <Sheet open={tx !== null} onClose={onClose} title="Reçu de transaction">
      {tx && (
        <div className="flex flex-col gap-4">
          <ReceiptCard tx={tx} />
          <PrimaryButton onClick={() => shareOnWhatsApp(tx)}>
            <MessageCircle className="size-5" />
            Partager le reçu sur WhatsApp
          </PrimaryButton>
        </div>
      )}
    </Sheet>
  )
}
